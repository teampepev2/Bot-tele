# Simpan token & config API key
BOT_TOKEN = "ISI_TOKEN_KAMU"