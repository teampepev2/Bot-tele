# Nanti buat koneksi SQLite disini
def init_db():
    print("Database disiapkan.")
