# Akan diisi fungsi scraping nanti
def dummy_scrape(game):
    return f"https://moddummy.com/{game.replace(' ', '-')}"
