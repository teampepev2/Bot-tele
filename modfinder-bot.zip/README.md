# ModFinderBot
Bot Telegram pencari MOD game dengan fitur pencarian otomatis, UI menarik, dan shortlink sponsor rotasi.

## Fitur:
- Pencarian otomatis MOD game
- Scraping dari beberapa situs MOD populer
- Sistem shortlink rotasi (premium & gratis)
- Referral sistem
- UI Telegram rapi (InlineKeyboard)
